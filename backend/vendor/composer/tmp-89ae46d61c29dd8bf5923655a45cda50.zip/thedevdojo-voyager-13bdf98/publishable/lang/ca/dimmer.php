<?php

return [
    'page'           => 'Pàgina|Pàgines',
    'page_link_text' => 'Veure totes les pàgines',
    'page_text'      => 'Tens :count :string a la base de dades. Fes click al boto de a sota per veure totes les pàgines. ',
    'post'           => 'Post|Posts',
    'post_link_text' => 'Veure tots els posts',
    'post_text'      => 'Tiene :count :string a la base de dades. Fes click al boto de a sota per veure tots els posts. ',
    'user'           => 'Usuario|Usuarios',
    'user_link_text' => 'Veure tots els usuaris',
    'user_text'      => 'Tens :count :string a la base de dades. Fes click al boto de a sota per veure tots els usuaris. ',
];
