<?php

return [
    'invalid'           => 'Json invàlid',
    'invalid_message'   => 'Sembla que has introduït un Json invàlid',
    'valid'             => 'Json vàlid',
    'validation_errors' => 'Errors de validació',
];
