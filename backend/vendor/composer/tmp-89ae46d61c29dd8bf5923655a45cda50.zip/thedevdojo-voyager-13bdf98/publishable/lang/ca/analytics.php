<?php

return [
    'by_pageview'            => 'Per pàgina',
    'by_sessions'            => 'Per sessions',
    'by_users'               => 'Per usuaris',
    'no_client_id'           => 'Per veure la analitica, es necessita una ID de client de Google Analytics i afegir-la a la configuració amb la clau <code>google_analytics_client_id</code>. Pots obtenir la clau de Google a la consola de desenvolupadors de Google: ',
    'set_view'               => 'Seleccionar una vista',
    'this_vs_last_week'      => 'Aquesta setmana vs la semana anterior',
    'this_vs_last_year'      => 'Any actual vs Any anterior',
    'top_browsers'           => 'Principals Navegadors',
    'top_countries'          => 'Principals països',
    'various_visualizations' => 'Varies visualizacions',
];
