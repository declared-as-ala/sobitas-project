<?php

return [
    'last_week' => 'La setmana passada',
    'last_year' => 'L\'any passat',
    'this_week' => 'Aquesta setmana',
    'this_year' => 'Aquest any',
];
