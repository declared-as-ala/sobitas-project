<?php

return [
    'avatar'        => 'Avatar',
    'edit'          => 'Editar el meu perfil',
    'edit_user'     => 'Editar usuari',
    'password'      => 'Contrasenya',
    'password_hint' => 'Deixar buit per mantenir la mateixa',
    'role'          => 'Rol',
    'user_role'     => 'Rol d\'usuari',
];
