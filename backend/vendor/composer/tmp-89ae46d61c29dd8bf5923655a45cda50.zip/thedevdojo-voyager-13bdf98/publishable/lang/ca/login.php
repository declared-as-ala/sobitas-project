<?php

return [
    'loggingin'    => 'Iniciant sessió',
    'signin_below' => 'Iniciar sessió:',
    'welcome'      => 'Benvingut a Voyager. L\'administrador que faltava a Laravel ',
];
