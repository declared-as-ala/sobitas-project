<?php

return [
    'footer_copyright'  => 'Fet amb <i class = "voyager-heart"> </i> per',
    'footer_copyright2' => 'Fet amb ron i inclús més ron',
];
