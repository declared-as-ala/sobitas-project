<?php

return [
    'symlink_created_text'   => 'Hem creat l\'enllaç simbòlic que faltava.',
    'symlink_created_title'  => 'Hem creat l\'enllaç simbòlic que faltava.',
    'symlink_failed_text'    => 'No s\'ha pogut crear l\'enllaç simbòlic que faltava. El teu proveïdor web no ens ho permet',
    'symlink_failed_title'   => 'No s\'ha pogut crear l\'enllaç simbòlic que faltava.',
    'symlink_missing_button' => 'Arregla-ho',
    'symlink_missing_text'   => 'No s\'ha pogut crear l\'enllaç simbòlic que faltava per a storage. Això pot afectar als elements multimedia.',
    'symlink_missing_title'  => 'No s\'ha pogut crear l\'enllaç simbòlic que faltava per a storage.',
];
