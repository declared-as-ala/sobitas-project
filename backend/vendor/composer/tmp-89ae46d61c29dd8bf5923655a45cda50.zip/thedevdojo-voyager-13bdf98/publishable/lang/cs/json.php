<?php

return [
    'invalid'           => 'Neplatný Json',
    'invalid_message'   => 'Vypadá to, že jste zvolil neplatný JSON.',
    'valid'             => 'Platný Json',
    'validation_errors' => 'Chyby validace',
];
