<?php

return [
    'invalid'           => 'Json i pavlefshëm',
    'invalid_message'   => 'Duket sikur keni futur disa JSON të pavlefshëm.',
    'valid'             => 'Valid Json',
    'validation_errors' => 'Gabimet e validimit',
];
