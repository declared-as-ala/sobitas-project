<?php

return [
    'footer_copyright'  => 'Bërë me <i class = "voyager-heart"> </ i> nga',
    'footer_copyright2' => 'Bërë me rum dhe rum më shumë',
];
