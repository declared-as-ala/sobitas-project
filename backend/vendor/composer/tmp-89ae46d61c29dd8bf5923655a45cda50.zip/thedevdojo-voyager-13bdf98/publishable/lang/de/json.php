<?php

return [
    'invalid'           => 'Ungültiges JSON',
    'invalid_message'   => 'Es scheint Sie haben ungültiges JSON eingebracht.',
    'valid'             => 'Gültiges JSON',
    'validation_errors' => 'Validierungsfehler',
];
