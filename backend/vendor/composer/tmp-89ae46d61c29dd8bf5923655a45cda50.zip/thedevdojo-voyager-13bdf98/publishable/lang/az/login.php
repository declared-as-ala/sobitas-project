<?php

return [
    'loggingin'    => 'Sistemə giriş',
    'signin_below' => 'İdarəetmə panelinə giriş',
    'welcome'      => 'Laraveldə çatışmayan, idarəetmə paneli',
];
