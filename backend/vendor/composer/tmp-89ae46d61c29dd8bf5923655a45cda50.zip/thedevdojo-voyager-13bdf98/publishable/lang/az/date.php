<?php

return [
    'last_week' => 'Keçən həftə',
    'last_year' => 'Keçən il',
    'this_week' => 'Bu həftə',
    'this_year' => 'Bu il',
];
