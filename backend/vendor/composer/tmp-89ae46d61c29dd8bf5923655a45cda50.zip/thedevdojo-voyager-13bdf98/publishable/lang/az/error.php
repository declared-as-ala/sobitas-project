<?php

return [
    'symlink_created_text'   => 'Sizin üçün link yaratdlq.',
    'symlink_created_title'  => 'Çatışmayan məlumat anbarı bağlantısı yaradıldı.',
    'symlink_failed_text'    => 'Çatışmayan linki yaratmaq alınmadı: görünür, hostinq problemidir.',
    'symlink_failed_title'   => 'Məlumat anbarı üçün keçid linki yaratmaq alınmadı.',
    'symlink_missing_button' => 'Düzəldin',
    'symlink_missing_text'   => 'Datastore linki tapılmadı: Bu, media fayllarının endirilməsi ilə bağlı problemlər yarada bilər.',
    'symlink_missing_title'  => 'Məlumat anbarına keçid linki yoxdur.',
];
