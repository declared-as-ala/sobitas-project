<?php

return [
    'additional_fields'=> 'Əlavə sahələr',
    'category'         => 'Məqalənin Kateqoriyası',
    'content'          => 'Məqalənin mətni',
    'details'          => 'Xüsusiyyətlər',
    'excerpt'          => 'Anons <small>məqalənin qısa təsviri</small>',
    'image'            => 'Şəkil',
    'meta_description' => 'Təsvir (meta)',
    'meta_keywords'    => 'Açar sözləri (meta)',
    'new'              => 'Yeni',
    'seo_content'      => 'SEO mətni',
    'seo_title'        => 'SEO adı',
    'slug'             => 'slug',
    'status'           => 'Paylaşımın statusu',
    'status_draft'     => 'Cızmaqara',
    'status_pending'   => 'Moderasiyada',
    'status_published' => 'Paylaşılıb',
    'title'            => 'Başlıq',
    'title_sub'        => 'Məqalənin başlığı',
    'update'           => 'Yenilə',
];
