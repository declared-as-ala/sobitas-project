<?php

return [
    'avatar'           => 'Foto',
    'edit'             => 'Profil ayarları',
    'edit_user'        => 'Profili dəyiş',
    'password'         => 'Şifrə',
    'password_hint'    => 'Eyni dəyəri saxlamaq üçün sahəni boş saxlayın',
    'role'             => 'Qrup',
    'roles'            => 'Rol',
    'role_default'     => 'Susmaya görə rol',
    'roles_additional' => 'Əlavə rollar',
    'user_role'        => 'İstifadəçi qrupu',
];
