<?php

return [
    'footer_copyright'  => '<i class="voyager-heart"></i> yaradılıb',
    'footer_copyright2' => 'Rom altında yaradılıb :) ',
];
