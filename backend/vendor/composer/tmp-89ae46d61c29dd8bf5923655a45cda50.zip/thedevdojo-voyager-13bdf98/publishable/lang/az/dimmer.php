<?php

return [
    'page'           => 'səhifə|səhifələr',
    'page_link_text' => 'Bütün səhifələr',
    'page_text'      => 'Verilənlər bazasında :count :string',
    'post'           => 'yazı|yazılar',
    'post_link_text' => 'Bütün yazılar',
    'post_text'      => 'Verilənlər bazasında :count :string',
    'user'           => 'istifadəçi|istifadəçilər',
    'user_link_text' => 'Bütün istifadəçilər',
    'user_text'      => 'Verilənlər bazasında :count :string',
];
