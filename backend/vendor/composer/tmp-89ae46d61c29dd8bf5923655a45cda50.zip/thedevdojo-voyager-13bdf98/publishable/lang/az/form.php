<?php

return [
    'field_password_keep'          => 'Əgər şifrəni dəyişmək istəmirsinizsə, boş saxlayın',
    'field_select_dd_relationship' => 'Mütləq müvafiq əlaqələri (relationship) :class sinifinin :method metodunda ayarlayın.',
    'type_checkbox'                => 'Bayraq',
    'type_codeeditor'              => 'Kod redaktoru',
    'type_file'                    => 'Fayl',
    'type_image'                   => 'Şəkil',
    'type_radiobutton'             => 'Radio-knopka',
    'type_richtextbox'             => 'Vizual redaktor',
    'type_selectdropdown'          => 'Düşən siyahı',
    'type_textarea'                => 'Çoxsətirli mətn',
    'type_textbox'                 => 'Təksətirli mətn',
];
