<?php

return [
    'by_pageview'            => 'Səhifənin baxışlarına əsasən',
    'by_sessions'            => 'Sessiyalara əsasən',
    'by_users'               => 'İstifadəçilərə əsasən',
    'no_client_id'           => 'Analitikanı görmək üçün, siz gərək google analikanın "client id"-ni əldə edəsiniz və öz ayarlarınıza <code>google_analytics_client_id</code> açarı kimi əlavə edəsiniz. Açarı Google developer konsolundan əldə edə bilərsiniz: ',
    'set_view'               => 'Görünüşü seçin',
    'this_vs_last_week'      => 'Hazırki və Keçən həftə',
    'this_vs_last_year'      => 'Hazırki və Keçən il',
    'top_browsers'           => 'Top brauzerlər',
    'top_countries'          => 'Top ölkələr',
    'various_visualizations' => 'Fərqli vizualizasiyalar',
];
