<?php

return [
    'invalid'           => 'JSON yanlış formatı',
    'invalid_message'   => 'JSON yanlış format daxil edilib',
    'valid'             => 'JSON düzgün format',
    'validation_errors' => 'Məlumatları yoxlayarkən xəta',
];
