<?php

return [
    'loggingin'    => 'Մուտք գործել',
    'signin_below' => 'Մուտք գործել Ստորև:',
    'welcome'      => 'Բարի գալուստ Voyager: Laravel-ի համար անհայտ ղեկավարող',
];
