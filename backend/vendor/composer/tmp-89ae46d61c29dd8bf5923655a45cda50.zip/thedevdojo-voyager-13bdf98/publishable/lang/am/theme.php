<?php

return [
    'footer_copyright'  => 'Պատրաստված է <i class="voyager-heart"></i> կողմից',
    'footer_copyright2' => 'Պատրաստված է սիրով և նույնիսկ ավելի մեծ սիրով:',
];
