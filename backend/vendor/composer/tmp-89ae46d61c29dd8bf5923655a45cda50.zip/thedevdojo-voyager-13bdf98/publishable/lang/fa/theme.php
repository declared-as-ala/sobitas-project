<?php

return [
    'footer_copyright'  => 'ایجاد شده <i class="voyager-heart"></i> با',
    'footer_copyright2' => 'Made with rum and even more rum',
];
