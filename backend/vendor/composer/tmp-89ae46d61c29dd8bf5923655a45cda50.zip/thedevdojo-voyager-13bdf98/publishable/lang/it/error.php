<?php

return [
    'symlink_created_text'   => 'Abbiamo appena creato il symlink mancante per te.',
    'symlink_created_title'  => 'Il symlink per lo storage mancante è stato creato',
    'symlink_failed_text'    => 'Non siamo riusciti a generare il symlink mancante per l\'applicazione. Sembra che il tuo provider di hosting non lo supporti.',
    'symlink_failed_title'   => 'Non è possibile creare il symlink mancante per lo storage',
    'symlink_missing_button' => 'Riparalo',
    'symlink_missing_text'   => 'Non abbiamo trovato un symlink per lo storage. Questo potrebbe causare problemi nel caricare file multimediali dal browser.',
    'symlink_missing_title'  => 'Symlink per lo storage mancante',
];
