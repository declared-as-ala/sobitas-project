<?php

return [
    'field_password_keep'          => 'Αφήστε το κενό για να παραμείνει το ίδιο',
    'field_select_dd_relationship' => 'Σιγουρευτείτε ότι έχετε ρυθμίσει την κατάλληλη σχέση στη μέθοδο :method της κλάσης :class',
    'type_checkbox'                => 'Πεδίο ναι/όχι (check box)',
    'type_codeeditor'              => 'Πεδίο κώδικα',
    'type_file'                    => 'Αρχείο',
    'type_image'                   => 'Εικόνα',
    'type_radiobutton'             => 'Πεδίο επιλογής (radio)',
    'type_richtextbox'             => 'Πεδίο επεξεργασίας κειμένου',
    'type_selectdropdown'          => 'Πεδίο επιλογής (dropdown)',
    'type_textarea'                => 'Μεγάλο πεδίο κειμένου',
    'type_textbox'                 => 'Πεδίο κειμένου',
];
