# Prerequisites

Before installing Voyager make sure you have installed one of the following versions of Laravel:
- Laravel 8
- Laravel 9

Additionally Voyager requires you to use PHP 7.3 or newer. Laravel requires you to use PHP 8 or newer when using Laravel 9.