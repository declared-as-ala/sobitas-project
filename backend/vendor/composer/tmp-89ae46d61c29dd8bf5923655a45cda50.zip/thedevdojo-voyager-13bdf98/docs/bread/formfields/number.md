# Number

```php
{
    "step" : 0.1,
    "min" : 0,
    "max" : 10,
    "default": 1,
}
```

These are standard attributes for number input field, default value for step is any if not defined.
